# Hangout — chat rooms with friends

Sign up with a username and password, make a room, share the 6-letter code, and chat live.

## What's inside

| File | What it does |
|---|---|
| `server.js` | The server: accounts, room codes, live messages |
| `public/index.html` | The page layout |
| `public/style.css` | The look (auto dark mode included) |
| `public/app.js` | Everything that happens in the browser |
| `package.json` | Tells Node which packages to install |

Accounts, rooms and the last 200 messages per room are saved in `data.json`, which the server creates by itself. Passwords are scrambled (hashed) before they're saved, so not even you can read them.

## Try it on your own computer

1. Install **Node.js** (the "LTS" version) from https://nodejs.org
2. Unzip this folder, open a terminal in it, and run:
   ```
   npm install
   npm start
   ```
3. Open http://localhost:3000 in your browser. Open a second browser (or a private window) to sign up as a second person and test chatting.

Friends can't reach `localhost` — for that, put it online (below).

## Put it online for free

### Option A: Replit (easiest, keeps your saved chats)
1. Make a free account at https://replit.com
2. Create a new Repl → choose **Node.js** → drag all these files in (keep the `public` folder).
3. Press **Run**. Replit gives you a link — send it to your friends.
4. To keep it online all the time, use Replit's **Deploy** button.

### Option B: Render
1. Put this folder in a GitHub repository.
2. At https://render.com → **New → Web Service** → pick the repo.
3. Build command: `npm install` · Start command: `npm start` · Plan: Free.
4. Heads-up: on Render's free plan the saved file can be wiped when the server restarts, so accounts and messages may reset. Fine for testing; Replit's Deploy is better if you want things to stick around.

## Rules built in
- Usernames: 3–20 letters, numbers or `_` (not case-sensitive, so `Alex` and `alex` are the same account)
- Passwords: 6+ characters
- Messages: up to 500 characters; sending too fast gets slowed down
- Click the room code at the top of a chat to copy it
- If everyone leaves a room, it's deleted

## Changing the name
Search for `Hangout` in `public/index.html` and replace it with whatever you want to call your site.

## Keep in mind
There's no "forgot password" (since there's no email), so tell friends to remember theirs. Anyone with a room code can join that room, so only share codes with people you know.
