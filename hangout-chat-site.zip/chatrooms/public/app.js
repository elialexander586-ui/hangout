// Hangout front-end
const $ = (id) => document.getElementById(id);

let mode = "login";
let token = null;
let me = null;
let socket = null;
let rooms = [];          // [{code, name, owner, members}]
let current = null;      // open room code
const unread = {};

try { token = localStorage.getItem("hangout_token"); } catch {}

// ---------- toast ----------
let toastTimer;
function toast(text) {
  const t = $("toast");
  t.textContent = text;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
}

// ---------- auth screen ----------
document.querySelectorAll(".tab").forEach((tab) =>
  tab.addEventListener("click", () => {
    mode = tab.dataset.mode;
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === tab));
    $("authSubmit").textContent = mode === "login" ? "Log in" : "Create account";
    $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
    $("authError").textContent = "";
  })
);

$("authForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("authError").textContent = "";
  $("authSubmit").disabled = true;
  try {
    const res = await fetch("/api/" + mode, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: $("username").value.trim(), password: $("password").value }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Something went wrong");
    token = data.token;
    try { localStorage.setItem("hangout_token", token); } catch {}
    $("password").value = "";
    connect();
  } catch (err) {
    $("authError").textContent = err.message;
  } finally {
    $("authSubmit").disabled = false;
  }
});

function showAuth() {
  $("main").classList.add("hidden");
  $("auth").classList.remove("hidden");
}
function showMain() {
  $("auth").classList.add("hidden");
  $("main").classList.remove("hidden");
}

$("logoutBtn").addEventListener("click", async () => {
  try {
    await fetch("/api/logout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token }) });
  } catch {}
  try { localStorage.removeItem("hangout_token"); } catch {}
  token = null; me = null; current = null; rooms = [];
  if (socket) { socket.disconnect(); socket = null; }
  closeRoomView();
  showAuth();
});

// ---------- connection ----------
function connect() {
  if (socket) socket.disconnect();
  socket = io({ auth: { token } });

  socket.on("connect_error", (err) => {
    if (err.message === "not_logged_in") {
      try { localStorage.removeItem("hangout_token"); } catch {}
      token = null;
      socket.disconnect();
      showAuth();
    }
  });

  socket.on("hello", (data) => {
    me = data.username;
    rooms = data.rooms;
    $("meName").textContent = me;
    showMain();
    renderRooms();
    if (current && rooms.some((r) => r.code === current)) openRoom(current); // reconnect
  });

  socket.on("message", ({ code, msg }) => {
    if (code === current) {
      addMessage(msg, true);
      clearTyping(msg.from);
    } else {
      unread[code] = (unread[code] || 0) + 1;
      renderRooms();
    }
  });

  socket.on("online", ({ code, users }) => {
    if (code !== current) return;
    $("onlineList").textContent = users.length
      ? users.map((u) => (u === me ? u + " (you)" : u)).join(", ") + " online"
      : "nobody online";
  });

  socket.on("typing", ({ code, from }) => {
    if (code === current) showTyping(from);
  });

  socket.on("notice", toast);
}

// ---------- rooms list ----------
function renderRooms() {
  const list = $("roomList");
  list.replaceChildren();
  $("noRooms").classList.toggle("hidden", rooms.length > 0);
  for (const r of rooms) {
    const li = document.createElement("li");
    const b = document.createElement("button");
    if (r.code === current) b.classList.add("active");
    const title = document.createElement("span");
    title.className = "room-title";
    title.textContent = r.name;
    b.append(title);
    if (unread[r.code]) {
      const u = document.createElement("span");
      u.className = "unread";
      u.textContent = unread[r.code];
      b.append(u);
    } else {
      const meta = document.createElement("span");
      meta.className = "room-meta";
      meta.textContent = r.code;
      b.append(meta);
    }
    b.addEventListener("click", () => openRoom(r.code));
    li.append(b);
    list.append(li);
  }
}

function upsertRoom(room) {
  const i = rooms.findIndex((r) => r.code === room.code);
  if (i >= 0) rooms[i] = room; else rooms.unshift(room);
}

$("joinForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const code = $("joinCode").value.trim().toUpperCase();
  $("sideError").textContent = "";
  if (!code) return;
  socket.emit("joinRoom", { code }, (res) => {
    if (res.error) return ($("sideError").textContent = res.error);
    $("joinCode").value = "";
    upsertRoom(res.room);
    openRoom(res.room.code);
  });
});

$("newRoomBtn").addEventListener("click", () => {
  $("newRoomName").value = "";
  $("newRoomDialog").showModal();
});
$("newRoomDialog").addEventListener("close", () => {
  if ($("newRoomDialog").returnValue !== "ok") return;
  socket.emit("createRoom", { name: $("newRoomName").value }, (res) => {
    if (res.error) return ($("sideError").textContent = res.error);
    upsertRoom(res.room);
    openRoom(res.room.code);
    toast("Room made! Share the code: " + res.room.code);
  });
});

// ---------- chat view ----------
let lastDay = null;
let lastFrom = null;

function openRoom(code) {
  socket.emit("openRoom", { code }, (res) => {
    if (res.error) return toast(res.error);
    current = code;
    unread[code] = 0;
    upsertRoom(res.room);
    renderRooms();
    $("chatEmpty").classList.add("hidden");
    $("chatRoom").classList.remove("hidden");
    $("main").classList.add("in-room");
    $("roomName").textContent = res.room.name;
    $("roomCode").textContent = res.room.code;
    $("messages").replaceChildren();
    $("typing").textContent = "";
    lastDay = null; lastFrom = null;
    res.messages.forEach((m) => addMessage(m, false));
    scrollDown();
    $("msgInput").focus();
  });
}

function closeRoomView() {
  current = null;
  $("chatRoom").classList.add("hidden");
  $("chatEmpty").classList.remove("hidden");
  $("main").classList.remove("in-room");
  renderRooms();
}

$("backBtn").addEventListener("click", closeRoomView);

$("leaveBtn").addEventListener("click", () => {
  if (!current) return;
  const r = rooms.find((x) => x.code === current);
  if (!confirm(`Leave "${r ? r.name : current}"? You can rejoin with the code.`)) return;
  const code = current;
  socket.emit("leaveRoom", { code }, () => {
    rooms = rooms.filter((x) => x.code !== code);
    closeRoomView();
  });
});

$("codeBtn").addEventListener("click", async () => {
  const code = $("roomCode").textContent;
  try {
    await navigator.clipboard.writeText(code);
    toast("Copied " + code + " — send it to your friends!");
  } catch {
    toast("Room code: " + code);
  }
});

function fmtTime(ts) {
  return new Date(ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
function fmtDay(ts) {
  const d = new Date(ts), today = new Date();
  const y = new Date(); y.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });
}

function addMessage(m, live) {
  const box = $("messages");
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 120;

  const day = new Date(m.at).toDateString();
  if (day !== lastDay) {
    const sep = document.createElement("li");
    sep.className = "day-sep";
    sep.textContent = fmtDay(m.at);
    box.append(sep);
    lastDay = day;
    lastFrom = null;
  }

  const li = document.createElement("li");
  li.className = "msg" + (m.from === me ? " mine" : "");
  if (m.from !== lastFrom && m.from !== me) {
    const who = document.createElement("div");
    who.className = "who";
    who.textContent = m.from;
    li.append(who);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = m.text; // textContent = safe, no HTML injection
  bubble.title = fmtTime(m.at);
  li.append(bubble);
  box.append(li);
  lastFrom = m.from;

  if (!live || nearBottom || m.from === me) scrollDown();
}

function scrollDown() {
  const box = $("messages");
  box.scrollTop = box.scrollHeight;
}

$("sendForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const text = $("msgInput").value.trim();
  if (!text || !current) return;
  socket.emit("message", { code: current, text });
  $("msgInput").value = "";
});

// typing indicator
let typingSent = 0;
$("msgInput").addEventListener("input", () => {
  if (!current || Date.now() - typingSent < 2000) return;
  typingSent = Date.now();
  socket.emit("typing", { code: current });
});
const typers = new Map();
function showTyping(name) {
  clearTimeout(typers.get(name));
  typers.set(name, setTimeout(() => clearTyping(name), 3000));
  renderTyping();
}
function clearTyping(name) {
  clearTimeout(typers.get(name));
  typers.delete(name);
  renderTyping();
}
function renderTyping() {
  const names = [...typers.keys()];
  $("typing").textContent =
    names.length === 0 ? "" :
    names.length === 1 ? names[0] + " is typing…" :
    names.join(", ") + " are typing…";
}

// ---------- start ----------
if (token) connect(); else showAuth();
