// Chat Rooms server
// Sign up with username + password, create a room code, friends join with the code.

const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const { Server } = require("socket.io");

const PORT = process.env.PORT || 3000;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, "data.json");
const MAX_HISTORY = 200;     // messages kept per room
const MAX_MESSAGE = 500;     // characters per message

// ---------- tiny file "database" ----------
let db = { users: {}, sessions: {}, rooms: {} };
try {
  if (fs.existsSync(DATA_FILE)) db = { ...db, ...JSON.parse(fs.readFileSync(DATA_FILE, "utf8")) };
} catch (e) {
  console.error("Could not read data file, starting fresh:", e.message);
}
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFile(DATA_FILE + ".tmp", JSON.stringify(db), (err) => {
      if (err) return console.error("Save failed:", err.message);
      fs.rename(DATA_FILE + ".tmp", DATA_FILE, () => {});
    });
  }, 300);
}

// ---------- helpers ----------
const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const key = (name) => name.toLowerCase();

function newToken() {
  return crypto.randomBytes(32).toString("hex");
}
function newRoomCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I to avoid mix-ups
  let code;
  do {
    code = Array.from(crypto.randomBytes(6), (b) => chars[b % chars.length]).join("");
  } while (db.rooms[code]);
  return code;
}
function userFromToken(token) {
  if (typeof token !== "string") return null;
  const s = db.sessions[token];
  return s ? db.users[s.user] || null : null;
}
function roomSummary(code) {
  const r = db.rooms[code];
  return { code, name: r.name, owner: r.owner, members: r.members.length };
}

// simple per-key rate limiter
const hits = new Map();
function limited(id, max, windowMs) {
  const now = Date.now();
  const list = (hits.get(id) || []).filter((t) => now - t < windowMs);
  list.push(now);
  hits.set(id, list);
  return list.length > max;
}

// ---------- web server ----------
const app = express();
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/signup", async (req, res) => {
  if (limited("signup:" + req.ip, 10, 60 * 60 * 1000))
    return res.status(429).json({ error: "Too many sign-ups. Try again later." });
  const { username, password } = req.body || {};
  if (typeof username !== "string" || !USERNAME_RE.test(username))
    return res.status(400).json({ error: "Username must be 3–20 letters, numbers or _" });
  if (typeof password !== "string" || password.length < 6 || password.length > 100)
    return res.status(400).json({ error: "Password must be at least 6 characters" });
  if (db.users[key(username)]) return res.status(409).json({ error: "That username is taken" });

  const hash = await bcrypt.hash(password, 10);
  db.users[key(username)] = { name: username, hash, rooms: [], created: Date.now() };
  const token = newToken();
  db.sessions[token] = { user: key(username), created: Date.now() };
  save();
  res.json({ token, username });
});

app.post("/api/login", async (req, res) => {
  if (limited("login:" + req.ip, 20, 15 * 60 * 1000))
    return res.status(429).json({ error: "Too many tries. Wait a few minutes." });
  const { username, password } = req.body || {};
  const user = typeof username === "string" ? db.users[key(username)] : null;
  const ok = user && typeof password === "string" && (await bcrypt.compare(password, user.hash));
  if (!ok) return res.status(401).json({ error: "Wrong username or password" });
  const token = newToken();
  db.sessions[token] = { user: key(user.name), created: Date.now() };
  save();
  res.json({ token, username: user.name });
});

app.post("/api/logout", (req, res) => {
  const { token } = req.body || {};
  if (typeof token === "string" && db.sessions[token]) {
    delete db.sessions[token];
    save();
  }
  res.json({ ok: true });
});

// ---------- live chat ----------
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 4096 });

io.use((socket, next) => {
  const user = userFromToken(socket.handshake.auth && socket.handshake.auth.token);
  if (!user) return next(new Error("not_logged_in"));
  socket.data.user = user;
  next();
});

function onlineIn(code) {
  const ids = io.sockets.adapter.rooms.get("room:" + code) || new Set();
  const names = new Set();
  for (const id of ids) {
    const s = io.sockets.sockets.get(id);
    if (s) names.add(s.data.user.name);
  }
  return [...names];
}
function broadcastOnline(code) {
  io.to("room:" + code).emit("online", { code, users: onlineIn(code) });
}

io.on("connection", (socket) => {
  const user = socket.data.user;
  const uKey = key(user.name);

  const myRooms = () =>
    db.users[uKey].rooms.filter((c) => db.rooms[c]).map(roomSummary);

  socket.emit("hello", { username: user.name, rooms: myRooms() });

  socket.on("createRoom", (data, reply) => {
    if (typeof reply !== "function") return;
    if (limited("create:" + uKey, 10, 60 * 60 * 1000))
      return reply({ error: "You're making rooms too fast. Try later." });
    let name = typeof data?.name === "string" ? data.name.trim().slice(0, 40) : "";
    if (!name) name = user.name + "'s room";
    const code = newRoomCode();
    db.rooms[code] = { name, owner: user.name, members: [uKey], messages: [], created: Date.now() };
    db.users[uKey].rooms.push(code);
    save();
    reply({ room: roomSummary(code) });
  });

  socket.on("joinRoom", (data, reply) => {
    if (typeof reply !== "function") return;
    if (limited("join:" + uKey, 30, 60 * 1000)) return reply({ error: "Slow down a bit." });
    const code = typeof data?.code === "string" ? data.code.trim().toUpperCase() : "";
    const room = db.rooms[code];
    if (!room) return reply({ error: "No room with that code" });
    if (!room.members.includes(uKey)) {
      room.members.push(uKey);
      db.users[uKey].rooms.push(code);
      save();
    }
    reply({ room: roomSummary(code) });
  });

  socket.on("openRoom", (data, reply) => {
    if (typeof reply !== "function") return;
    const code = typeof data?.code === "string" ? data.code : "";
    const room = db.rooms[code];
    if (!room || !room.members.includes(uKey)) return reply({ error: "You're not in that room" });
    // only "inside" one room at a time per tab
    for (const r of socket.rooms) if (r.startsWith("room:")) {
      socket.leave(r);
      broadcastOnline(r.slice(5));
    }
    socket.join("room:" + code);
    reply({ room: roomSummary(code), messages: room.messages });
    broadcastOnline(code);
  });

  socket.on("leaveRoom", (data, reply) => {
    const code = typeof data?.code === "string" ? data.code : "";
    const room = db.rooms[code];
    if (room) {
      room.members = room.members.filter((m) => m !== uKey);
      db.users[uKey].rooms = db.users[uKey].rooms.filter((c) => c !== code);
      if (room.members.length === 0) delete db.rooms[code];
      save();
      socket.leave("room:" + code);
      if (db.rooms[code]) broadcastOnline(code);
    }
    if (typeof reply === "function") reply({ ok: true });
  });

  socket.on("message", (data) => {
    const code = typeof data?.code === "string" ? data.code : "";
    const room = db.rooms[code];
    if (!room || !room.members.includes(uKey) || !socket.rooms.has("room:" + code)) return;
    let text = typeof data?.text === "string" ? data.text.trim() : "";
    if (!text) return;
    if (limited("msg:" + uKey, 8, 5000)) {
      socket.emit("notice", "You're sending messages too fast.");
      return;
    }
    text = text.slice(0, MAX_MESSAGE);
    const msg = { id: crypto.randomUUID(), from: user.name, text, at: Date.now() };
    room.messages.push(msg);
    if (room.messages.length > MAX_HISTORY) room.messages.splice(0, room.messages.length - MAX_HISTORY);
    save();
    io.to("room:" + code).emit("message", { code, msg });
  });

  socket.on("typing", (data) => {
    const code = typeof data?.code === "string" ? data.code : "";
    if (!socket.rooms.has("room:" + code)) return;
    socket.to("room:" + code).emit("typing", { code, from: user.name });
  });

  socket.on("disconnecting", () => {
    const codes = [...socket.rooms].filter((r) => r.startsWith("room:")).map((r) => r.slice(5));
    setImmediate(() => codes.forEach((c) => db.rooms[c] && broadcastOnline(c)));
  });
});

server.listen(PORT, () => console.log(`Chat Rooms running on http://localhost:${PORT}`));
